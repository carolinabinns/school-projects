#ifndef CODE_H
#define CODE_H

#include <vector>
#include <iostream>
#include "d_random.h"
#include <algorithm>
using namespace std;

class code{
	public:
		code();
		//overload constructor, if storing a guess pass in values
		//if not storing a guess, randomize the vector
		code(int el1, int el2, int el3, int el4);	
		int checkCorrect(code corr);
		int initRandom();
		int checkIncorrect(code incorr);
	private:
		vector <int> intVectors;// init vector
};

#endif
