
//Grace Carroll, Carolina Binns
//Fundamentals of Engineering Algorithms
//
//Project 1
//
//Compiled on Dev C++ using VLab on a MAC

#include "code.h"
#include "d_random.h"
#include "mastermind.h"

code::code(){
	//if no values specified, assume random code
	intVectors.push_back(initRandom());
	intVectors.push_back(initRandom());
	intVectors.push_back(initRandom());
	intVectors.push_back(initRandom());
}

code::code(int el1, int el2, int el3, int el4){
	//initialize vector with specified values
	intVectors.push_back(el1);
	intVectors.push_back(el2);
	intVectors.push_back(el3);
	intVectors.push_back(el4);
}

int code::initRandom(){
	int rand = 0;
	randomNumber n1;
	rand = n1.random(4)+1;
	return rand;
}

code::checkCorrect(code corr){
	int numCorr = 0;
	for(int i =0; i<intVectors.size(); i++){
		if (intVectors[i] == corr.intVectors[i])
		numCorr++;
	}
	return numCorr;
}

code::checkIncorrect(code incorr){
	int numOnes, numTwos, numThrees, numFours, numSemiOnes, numSemiTwos, numSemiThrees, numSemiFours;
	vector <int> numSemiCorr;
	for (int i =0; i<intVectors.size(); i++){
		for (int j = 0; j<intVectors.size(); j++){
			if (incorr.intVectors[j] == intVectors[i] && (i != j)){
				numSemiCorr.push_back(incorr.intVectors[j]); 
			}
		}
	}
	sort(numSemiCorr.begin(),numSemiCorr.end());
	
	for (int i = 0; i<intVectors.size(); i++){
		if(intVectors[i] == 1)
			numOnes++;
		if(intVectors[i] == 2)
			numTwos++;
		if(intVectors[i] == 3)
			numThrees++;
		if(intVectors[i] == 4)
			numFours++;
	}
	
	for (int i = 0; i<numSemiCorr.size(); i++){
		if(intVectors[i] == 1)
			numSemiOnes++;
		if(intVectors[i] == 2)
			numSemiTwos++;
		if(intVectors[i] == 3)
			numSemiThrees++;
		if(intVectors[i] == 4)
			numSemiFours++;
	}
	
	for (int i = 0; i<numSemiCorr.size()-1; i++){
		if(numSemiCorr[i]==numSemiCorr[i+1])
			numSemiCorr.erase(numSemiCorr.begin() + i);
	}
	return numSemiCorr.size();
		
}

//main method just so i can compile it and see if there are errors
int main(){
	
	return 0;
}
