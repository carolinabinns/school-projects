#include<iostream>
#include "mastermind.h"
#include "code.h"
#include "response.h"
#include "d_random.h"

using namespace std;

mastermind::printSecretCode(){
	cout<<"The secret code is: ";
	for (int i=0; i<4; i++){
		cout<<theCode[i];
	}
}

mastermind::humanGuess(){
	bool validInput = true;
	while(validInput){
		cout<<"Enter your guess:";
		cin>>g1>>g2>>g3>>g4;
		if ( ( g1==1 || g1==2 || g1==3 || g1==4 ) && ( g2==1 || g2==2 || g2==3 || g2==4 ) 
		&& ( g3==1 || g3==2 || g3==3 || g3==4 ) && ( g4==1 || g4==2 || g4==3 || g4==4 ) ) 
			validInput = false;
		else
			cout<<"Invalid guess. Enter four digits between 1 and 4."<<endl;
	}
	
	code guess(g1, g2, g3, g4);
	return guess;
}

mastermind::getResponse(&g,&c){ 
	int correct, incorrect;
	correct = checkCorrect(g);
	incorrect = checkIncorrect(g);	
	response r1(correct, incorrect);
}

mastermind::isSolved(&rsp){ 
	if (rsp[0]==4)
		return true;
	else 
		return false;
}

mastermind::playGame(){
	bool wincheck;
	code theCode; //initializes secret code
	theCode.printSecretCode(); //prints secret code, for testing purposes 
	for (int i=0; i<10; i++){
		playerGuess = humanGuess();	
		gameResponse = getResponse(playerGuess, theCode);
		wincheck = isSolved(gameResponse);
		if (wincheck == true){
			cout<<"You win!" 
			printSecretCode();
			exit;
		}
			
	}
	cout<<"You lose!"
	printSecretCode();
	
}

