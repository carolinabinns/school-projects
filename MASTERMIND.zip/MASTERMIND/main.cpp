//Grace Carroll, Carolina Binns
//Project 1
//main.cpp

#include "mastermind.h"
#include "code.h"
#include "response.h"

int main(){
	mastermind m1;
	m1.playGame();
	return 0;
}
