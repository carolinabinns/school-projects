//header file for mastermind class

#ifndef MASTERMIND_H
#define MASTERMIND_H

#include "code.h"
#include "response.h"	

class mastermind {
	public:
		void printSecretCode(); //prints secret code
		code humanGuess();
		response getResponse(code &guess, code &theCode); //CHECK SYNTAX
		bool isSolved(response &respose); //CHECK SYNTAX
		void playGame();
	private:
		code theCode;
		
};

#endif
