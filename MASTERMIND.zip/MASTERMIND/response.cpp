#include "response.h"
#include "mastermind.h"
#include "code.h"

response::response(int c, int i){
	numCorrect = c;
	numIncorrect = i;
}

response::setCorrect(int c){
	numCorrect = c;
}

reponse::setIncorrect(int i){
	numIncorrect = i;
}

reponse::getCorrect(){
	return numCorrect;
}

reponse::getIncorrect(){
	return numIncorrect;
}

response::compare(&rsp){
	if ( ( numCorrect == rsp.getCorrect() ) && ( numIncorrect == rsp.getIncorrect() ) )
		return true;
	
}

response::printResponse(){
	cout<<"Number of correct digits in the correct location: "<<numCorrect<<endl;
	cout<<"Number of correct digits in the incorrect location: "<<numIncorrect<<endl;
}
