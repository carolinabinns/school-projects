#ifndef RESPONSE_H
#define RESPONSE_H
#include "mastermind.h"
#include "code.h"
#include <iostream>

using namespace std;

class response{
	public:
		response(int, int);
		void setCorrect(int);
		void setIncorrect(int);
		void getCorrect();
		void getIncorrect();
		bool compare(response &);
		void printResponse();
	private:
		int numCorrect;
		int numIncorrect;
};

#endif
